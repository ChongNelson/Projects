#include <stdio.h>

#include <p18f4620.h>
#include "I2C_Support.h"
#include "I2C.h"

#define ACCESS_CFG      0xAC
#define START_CONV      0xEE
#define READ_TEMP       0xAA
#define CONT_CONV       0x02
#define ACK     1
#define NAK     0


extern unsigned char second, minute, hour, dow, day, month, year;
extern unsigned char setup_second, setup_minute, setup_hour, setup_day, setup_month, setup_year;
extern unsigned char alarm_second, alarm_minute, alarm_hour, alarm_date;
extern unsigned char setup_alarm_second, setup_alarm_minute, setup_alarm_hour;


void DS1621_Init()
{
    char Device = 0x48;              // I2C address for the DS1621 device
   I2C_Write_Cmd_Write_Data (Device, ACCESS_CFG, CONT_CONV);
   I2C_Write_Cmd_Only(Device, START_CONV);
}

int DS1621_Read_Temp()
{
  char Device = 0x48;               
  char Cmd = READ_TEMP;
  char Data_Ret;    
  I2C_Start();                      // Start I2C protocol
  I2C_Write((Device << 1) | 0);     // Device address
  I2C_Write(Cmd);                   // Send register address
  I2C_ReStart();                    // Restart I2C
  I2C_Write((Device << 1) | 1);     // Initialize data read
  Data_Ret = I2C_Read(NAK);         //
  I2C_Stop(); 
  return Data_Ret;
}

void DS3231_Read_Time()
{
  char Device = 0x68;               // I2C address for the DS1621 device
  char Address = 0x00;              // Value for the register 0x00 pointing to the register 'second'
  char Data_Ret;    
  I2C_Start();                      // Start I2C protocol
  I2C_Write((Device << 1) | 0);     // DS3231 address Write mode
  I2C_Write(Address);               // Send register address
  I2C_ReStart();                    // Restart I2C
  I2C_Write((Device << 1) | 1);     // Initialize data read
  second = I2C_Read(ACK);           // Allows system to read register 'second' from DS3231
  minute = I2C_Read(ACK);           // Allows system to read register 'minute' from DS3231
  hour = I2C_Read(ACK);             // Allows system to read register 'hour' from DS3231
  dow = I2C_Read(ACK);              // Allows system to read register 'dow' from DS3231
  day = I2C_Read(ACK);              // Allows system to read register 'day from DS3231
  month = I2C_Read(ACK);            // Allows system to read register 'month' from DS3231
  year = I2C_Read(NAK);             // Allows system to read register 'year' from DS3231
  I2C_Stop();                       // 'NAK' terminates the read sequence

}

void DS3231_Setup_Time()
{
    char Device = 0x68;             // I2C address for the DS1621 device
    char Address = 0x00;            // Value for the register 0x00 pointing to the register 'second'
    second = 0x00;                  // Put in starting values for Terra Term
    minute = 0x01;                  // When the button 'EQ' is pressed,
    hour = 0x16;                    // the registers will reset to it's initial values.
    dow = 0x03;                     // While this happens, the registers will increment accordingly
    day = 0x28;
    month = 0x10;
    year = 0x21;
    I2C_Start();                        // Start I2C protocol
  I2C_Write((Device << 1) | 0);         // Device address Write mode
  I2C_Write(Address);                   // Send register address
  I2C_Write(second);                    // Initialize second
  I2C_Write(minute);                    // Initialize minute
  I2C_Write(hour);                      // Initialize hour
  I2C_Write(dow);                       // Initialize dow
  I2C_Write(day);                       // Initialize day
  I2C_Write(month);                     // Initialize month
  I2C_Write(year);                      // Initialize year
  I2C_Stop();                                  
}